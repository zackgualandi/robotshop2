/*

Zackery Gualandi 10/5/2016

*/

#include <iostream>
#include <string>
#include <vector>
#include<FL/Fl.H>
#include<FL/Fl_Box.H>
#include<FL/Fl_Window.H>
#include "RobotModel.h"
#include "Menu.h"

using namespace std;

void Menu::openMainMenu()
{
	
}

//////////////////
// BROWSE MENU
//////////////////

void Menu::openBrowseMenu()
{
	
}

void Menu::displayRobotModel(RobotModel selectedModel)
{
	
}

//////////////////
// CREATE MENU
//////////////////

void Menu::openCreateMenu()
{

}

void Menu::buildRobotModel(RobotModel selectedModel)
{

}

//////////////////
// Order MENU
//////////////////

void Menu::openOrderMenu()
{
	
}

void Menu::orderRobotModel(RobotModel selectedModel)
{
	
}